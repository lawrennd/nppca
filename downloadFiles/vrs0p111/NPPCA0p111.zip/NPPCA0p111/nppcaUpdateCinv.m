function Cinv = nppcaUpdateCinv(model, expectations, B, X)

% NPPCAUPDATECINV Update the latent precision for the noisy PPCA model.
%
% Cinv = nppcaUpdateCinv(model, expectations, B, X)
%

% Copyright (c) 2006 Guido Sanguinetti and Neil D. Lawrence
% nppcaUpdateCinv.m version 1.1



C = mean(expectations.xxT, 3) ...
    - 2*mean(expectations.x)'*model.m ...
    + model.m'*model.m;

Cinv = pdinv(C);