function m = nppcaUpdateM(model, expectations, B, X)

% NPPCAUPDATEM Update the latent mean for the noisy PPCA model.
%
% m = nppcaUpdateM(model, expectations, B, X)
%

% Copyright (c) 2006 Guido Sanguinetti and Neil D. Lawrence
% nppcaUpdateM.m version 1.1



m = mean(expectations.x);

