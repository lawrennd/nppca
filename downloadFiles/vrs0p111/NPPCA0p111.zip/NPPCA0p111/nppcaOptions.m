function options = nppcaOptions;

% NPPCAOPTIONS Set up an options vector for noisy PPCA.
%
% options = nppcaOptions;
%

% Copyright (c) 2006 Guido Sanguinetti and Neil D. Lawrence
% nppcaOptions.m version 1.4



options.tol = 1e-4;
options.stepChecks = 0; % Whether to check likelihood after each update.
options.display = 0; % whether or not to display progress in a figure.
options.maxIters = 500; % Number of EM iterations.
options.optimiser = foptions; % optimisation options for Sigma.
options.optimiser(2) = options.tol;
options.optimiser(3) = options.tol;
