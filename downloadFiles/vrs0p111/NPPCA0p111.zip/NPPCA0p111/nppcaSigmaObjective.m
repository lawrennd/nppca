function f = nppcaSigmaObjective(sigma, model, expectations, B, V);

% NPPCASIGMAOBJECTIVE Wrapper function for objective as a function of Sigma.
%
% f = nppcaSigmaObjective(sigma, model, expectations, B, V);
%

% Copyright (c) 2006 Guido Sanguinetti and Neil D. Lawrence
% nppcaSigmaObjective.m version 1.2



model.sigma = sigma;
f = nppcaLikelihoodBound(model, expectations, B, V);