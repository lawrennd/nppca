function Cinv = nppcaUpdateCinv(model, expectations, B, X)

% NPPCAUPDATECINV Update the latent precision for the noisy PPCA model.
%
% Cinv = nppcaUpdateCinv(model, expectations, B, X)

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% NPPCA toolbox version 0.1



C = mean(expectations.xxT, 3) ...
    - 2*mean(expectations.x)'*model.m ...
    + model.m'*model.m;

Cinv = pdinv(C);