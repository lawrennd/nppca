function m = nppcaUpdateM(model, expectations, B, X)

% NPPCAUPDATEM Update the latent mean for the noisy PPCA model.
%
% m = nppcaUpdateM(model, expectations, B, X)

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% NPPCA toolbox version 0.1



m = mean(expectations.x);

