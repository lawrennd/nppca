% DEMOC1I Demo of probabilistic PCA with noise on OC1I dataset. The dataset contains ~13K genes and 12 samples; approximate running time 18hrs.
%
%
% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% File version 0, dummy timestamp
% NPPCA toolbox version 0.1



% Fix a seed so that results are repeatable.
randn('seed', 2e5);
rand('seed', 2e5);
colordef white
% We request four latent dimensions, but model only uses 3.
latentDim = 7;

% Set up the options.
options = nppcaOptions;

% Load first 20 points from OC1 data.
[Y, varY] = nppcaLoadData('OC1');

[model, expectations] = nppcaMaster(Y, varY, latentDim, options);
