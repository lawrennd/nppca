function [S, varS]=reconstruct(model, expectations)

% RECONSTRUCT reproduces a denoised reconstruction of the gene expressions with errorbars.
%
% [S, varS]=reconstruct(model, expectations)

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% File version 0, dummy timestamp
% NPPCA toolbox version 0.1



N=size(expectations.x,1);
d=size(model.W,1);
S=expectations.x*model.W'+ones(N,1)*model.mu;
varS=zeros(N, d);
for i=1:N
  varS(i,:)=diag(model.W*(expectations.xxT(:,:,i)- ...
                                 expectations.x(i,:)'*expectations.x(i,:))*model.W')';
  if varS(i)<0
    error('Negative variance')
  end
end
