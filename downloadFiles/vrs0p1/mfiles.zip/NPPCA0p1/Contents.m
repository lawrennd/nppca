% NPPCA toolbox
% Version 0.1		29-Apr-2005
% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% 
% DEMOC1I Demo of probabilistic PCA with noise on OC1I dataset. The dataset contains ~13K genes and 12 samples; approximate running time 18hrs.
% DEMOOC1GATA3 Simple demo of probabilistic PCA with noise on reduced OC1 dataset. 
% GMOSREADTXT reads TXT file for the OC1 data files.
% NPPCAESTEP Estep for the noisy probabilistic PCA.
% NPPCAFAINIT Initialises NPPCA with factor analysis with constant errors
% NPPCAINIT Initialise a Noisy probabilistic PCA model.
% NPPCALIKELIHOODBOUND Gives the variational bound on the log likelihood for noisy PPCA.
% NPPCALIKELIHOODCHECK Compute the difference in likelhoods.
% NPPCALOADDATA Load a dataset for demonstrating noisy PPCA.
% NPPCAMASTER performs the noisy probabilistic PCA algorithm on a dataset.
% NPPCANEWTONUPDATELOGSIGMA performs a Newton update for the logsigma dependence of the likelihood.
% NPPCANEWTONUPDATESIGMA performs a Newton update for the sigma dependence of the likelihood.
% NPPCAOPTIONS Set up an options vector for noisy PPCA.
% NPPCAPROFILEPLOTTER shows comparison of reconstructed and original profile for genes.
% NPPCAREMOVEREDUNDANCY Remove the redundancy in m and Cinv.
% NPPCASIGMACURVATURE Wrapper function for curvature with respect to sigma.
% NPPCASIGMAGRADIENT Wrapper function for gradient with respect to sigma.
% NPPCASIGMAOBJECTIVE Wrapper function for bjective as a function of Sigma.
% NPPCAUPDATECINV Update the latent precision for the noisy PPCA model.
% NPPCAUPDATEM Update the latent mean for the noisy PPCA model.
% NPPCAUPDATEMU Update the mean for the noisy PPCA model.
% NPPCAUPDATEW Update the W matrice for a noisy probabilistic PCA model.
% RECONSTRUCT reproduces a denoised reconstruction of the gene expressions with errorbars.
