function f = nppcaSigmaObjective(sigma, model, expectations, B, V);

% NPPCASIGMAOBJECTIVE Wrapper function for bjective as a function of Sigma.
%
% f = nppcaSigmaObjective(sigma, model, expectations, B, V);

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% NPPCA toolbox version 0.1



model.sigma = sigma;
f = nppcaLikelihoodBound(model, expectations, B, V);