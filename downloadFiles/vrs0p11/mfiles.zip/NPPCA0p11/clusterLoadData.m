function [annotation, Y, varY] = clusterLoadData()

% NPPCALOADDATA Load a dataset for demonstrating noisy PPCA.
%
% [annotation, Y, varY] = clusterLoadData()

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% File version 1.1, Fri Jul 15 15:48:27 2005
% NPPCA toolbox version 0.11


 

   [Y, annotation, geneName] = ClustergmosReadTxt(['../../gMOS/data/OC1_cluster_profile_nrec2.txt']);
   [varY, annotation, geneName] = ClustergmosReadTxt(['../../gMOS/data/OC1_cluster_Var2.txt']);
   
   Y = Y(1:2:199,:);
   varY = varY(1:2:199,:);
   annotation = annotation(1:2:199,:);

 