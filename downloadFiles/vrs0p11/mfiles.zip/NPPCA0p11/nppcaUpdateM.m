function m = nppcaUpdateM(model, expectations, B, X)

% NPPCAUPDATEM Update the latent mean for the noisy PPCA model.
%
% m = nppcaUpdateM(model, expectations, B, X)

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% File version 1.1, Sat Dec 11 21:28:37 2004
% NPPCA toolbox version 0.11



m = mean(expectations.x);

