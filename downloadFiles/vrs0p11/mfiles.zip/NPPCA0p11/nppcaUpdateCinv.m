function Cinv = nppcaUpdateCinv(model, expectations, B, X)

% NPPCAUPDATECINV Update the latent precision for the noisy PPCA model.
%
% Cinv = nppcaUpdateCinv(model, expectations, B, X)

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% File version 1.1, Sat Dec 11 21:28:37 2004
% NPPCA toolbox version 0.11



C = mean(expectations.xxT, 3) ...
    - 2*mean(expectations.x)'*model.m ...
    + model.m'*model.m;

Cinv = pdinv(C);