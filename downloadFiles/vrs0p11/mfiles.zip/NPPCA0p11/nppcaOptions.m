function options = nppcaOptions;

% NPPCAOPTIONS Set up an options vector for noisy PPCA.
%
% options = nppcaOptions;

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% File version 1.4, Fri Jul 15 15:59:57 2005
% NPPCA toolbox version 0.11



options.tol = 1e-4;
options.stepChecks = 0; % Whether to check likelihood after each update.
options.display = 0; % whether or not to display progress in a figure.
options.maxIters = 500; % Number of EM iterations.
options.optimiser = foptions; % optimisation options for Sigma.
options.optimiser(2) = options.tol;
options.optimiser(3) = options.tol;
