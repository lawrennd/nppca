function f = nppcaSigmaObjective(sigma, model, expectations, B, V);

% NPPCASIGMAOBJECTIVE Wrapper function for bjective as a function of Sigma.
%
% f = nppcaSigmaObjective(sigma, model, expectations, B, V);

% Copyright (c) 2005 Guido Sanguinetti and Neil D. Lawrence
% File version 1.1, Thu Dec  9 12:46:15 2004
% NPPCA toolbox version 0.11



model.sigma = sigma;
f = nppcaLikelihoodBound(model, expectations, B, V);